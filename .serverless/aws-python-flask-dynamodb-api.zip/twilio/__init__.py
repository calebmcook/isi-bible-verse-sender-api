
__version_info__ = ('7', '16', '1')
__version__ = '.'.join(__version_info__)
